<?php
/**
 * Created by IntelliJ IDEA.
 * User: brad
 * Date: 4/3/15
 * Time: 3:29 PM
 */

header("Location: lessons/index.php");